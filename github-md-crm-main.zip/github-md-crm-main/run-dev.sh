export $(grep -v '^#' .env.dev | xargs -0)
cd back
go run .

